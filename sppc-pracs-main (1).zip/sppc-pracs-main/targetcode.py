class Conversion:
	def __init__(self, capacity):
		self.top = -1
		self.capacity = capacity
		# This array is used a stack
		self.array = []
		# Precedence setting
		self.output = []
		self.precedence = {'+':1, '-':1, '*':2, '/':2, '^':3}
	
	def isEmpty(self):
		return True if self.top == -1 else False

	def peek(self):
		return self.array[-1]
	
	# Pop the element from the stack
	def pop(self):
		if not self.isEmpty():
			self.top -= 1
			return self.array.pop()
		else:
			return "$"
	
	# Push the element to the stack
	def push(self, op):
		self.top += 1
		self.array.append(op)

	def isOperand(self, ch):
		return ch.isalpha()

	def notGreater(self, i):
		try:
			a = self.precedence[i]
			b = self.precedence[self.peek()]
			return True if a <= b else False
		except KeyError:
			return False

	def infixToPostfix(self, exp):
		for i in exp:
			if self.isOperand(i):
				self.output.append(i)
			
			# If the character is an '(', push it to stack
			elif i == '(':
				self.push(i)

			elif i == ')':
				while( (not self.isEmpty()) and
								self.peek() != '('):
					a = self.pop()
					self.output.append(a)
				if (not self.isEmpty() and self.peek() != '('):
					return -1
				else:
					self.pop()

			# An operator is encountered
			else:
				while(not self.isEmpty() and self.notGreater(i)):
					self.output.append(self.pop())
				self.push(i)

		# pop all the operator from the stack
		while not self.isEmpty():
			self.output.append(self.pop())

		return "".join(self.output)

exp = input("Enter a 3 address code: ")
obj = Conversion(len(exp))
postfix = obj.infixToPostfix(exp)

operators = ['+', '-', '*', '/']
i = 0

for char in str(postfix):
    if (char in operators):
        if (char == "+"):
            print('ADD R0 R1')
        elif (char == '-'):
            print('SUB R0 R1')
        elif (char == '*'):
            print('MUL R1 R0')
        else:
            print('DIV R0 R1')
    else:
        print('MOV R'+str(i), char)
    i += 1

