#include <stdio.h>
#include <string.h>

void main()
{
    char str[30];
    int state = 0;
    int _any = 0;
    printf("Enter a Relational Operator: \n");
    gets(str);

    for (int i = 0; i < strlen(str); i++)
    {
        switch (state)
        {
        case 0:
            if (str[i] == '<')
                state = 1;
            else if (str[i] == '=')
            {
                state = 5;
                printf("EQ");
            }
            else if (str[i] == '>')
                state = 6;
            break;
        case 1:
            if (str[i] == '=')
            {
                state = 2;
                printf("LE");
            }

            else if (str[i] == '>')
            {
                state = 3;
                printf("NE");
            }
            else
            {
                state = 4;
                printf("LT");
            }
            break;
        case 6:
            if (str[i] == '=')
            {
                state = 7;
                printf("GE");
            }
            else
            {
                state = 8;
                printf("GT");
            }
            break;
        }
    }
}