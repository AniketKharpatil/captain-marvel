code = ['MACRO',
        '&Lab ADDM &arg1 &arg2 &arg3',
        '&Lab A 1 &arg1',
        'A 2 &arg2',
        'A 3 &arg3',
        'MEND'
        ]

MNT = []
ALA = []
MDT = []
helper_ala = []
MDTC = 0

for i, line in enumerate(code):
    if line == 'MACRO':
        continue
    line_arr = line.split()
    if i == 1:
        name = line_arr[1]
        MNT.append([len(MNT), name, MDTC])
        index = 0
        for arg in line_arr:
            if arg == name:
                pass
            else:
                ALA.append([f'#{index}', arg])
                helper_ala.append(arg)
                index += 1
        MDT.append([len(MDT), line])
    else:
        entry = ''
        for field in line_arr:
            if field in helper_ala:
                entry += '#' + str(helper_ala.index(field)) + ' '
            else:
                entry += field + ' '
        MDT.append([len(MDT), entry.strip()])
MDTC = len(MDT)+1


print('MNT:' + '\n')
for _ in MNT:
    print(_)
print('\n')

print('ALA:' + '\n')
for _ in ALA:
    print(_)
print('\n')

print('MDT:' + '\n')
for _ in MDT:
    print(_)
print('\n')
