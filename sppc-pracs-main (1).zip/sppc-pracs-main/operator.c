#include<stdio.h>
void main()
{
    int i=0 , state=0, flag=0;
    char s[100];
    gets(s);
    while(s[i] !='\0')
          {
    switch(state){
             case 0: if(s[i]=='<')
                        state=1;
                       else
                        state=3;
                    break;
             case 1: if(s[i]=='=' )
                        state=2;
                        else if(s[i]=='>')
                            state=9;
                    break;

          }
        
        i++;
          }
          if(state==9)
            printf("NE");
        if(state==2)
            printf("LE");

}