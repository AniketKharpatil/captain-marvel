from curses.ascii import isalpha


string = input('Enter a string: ')

if(string[0].isalpha()):
    print('Valid Identifier')
elif(string[0] == '_'):
    print('Valid Identifier')
else:
    print('Invalid Identifier')